var searchData=
[
  ['bytediv',['byteDiv',['../group__fixmath.html#ga0c6fd804408a6789f49d3f5e07340eb0',1,'mozzi_fixmath.cpp']]],
  ['bytemod',['byteMod',['../group__fixmath.html#gaba3a1d38c23a4499cfb219412d0b115b',1,'mozzi_fixmath.cpp']]]
];
