var searchData=
[
  ['hifi',['HIFI',['../group__core.html#gae99eb43cb29bb03d862ae829999916c4',1,'MozziGuts.h']]]
];
