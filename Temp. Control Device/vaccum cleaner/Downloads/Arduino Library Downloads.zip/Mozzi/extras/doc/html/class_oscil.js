var class_oscil =
[
    [ "Oscil", "class_oscil.html#ac43b3d870a5c6da90cafa9d678829593", null ],
    [ "Oscil", "class_oscil.html#ab7dc5f97742d841fff6a4dca6d7242f3", null ],
    [ "atIndex", "class_oscil.html#a3b2ea7727b2ec911957b3862dbb6a8ec", null ],
    [ "getPhaseFractional", "class_oscil.html#aa774ef68b06f9652e6ac23d4e9332554", null ],
    [ "next", "class_oscil.html#a2a76960954a19c7b24dfb7524b740c8f", null ],
    [ "phaseIncFromFreq", "class_oscil.html#a184110cb1901d2742a6016b46cbea027", null ],
    [ "phMod", "class_oscil.html#abe39f0740f318c0ecfb405cfac641a13", null ],
    [ "setFreq", "class_oscil.html#a23121f22ea447918088a79c7f9748b3d", null ],
    [ "setFreq", "class_oscil.html#aa342e74f8e73edda0b0f042770e3fba4", null ],
    [ "setFreq_Q16n16", "class_oscil.html#a73b52741178ed490463d9ff471cebef3", null ],
    [ "setFreq_Q24n8", "class_oscil.html#abc8a4ee236f7fd45dda9dece7292b6e7", null ],
    [ "setPhase", "class_oscil.html#ab7b740eec56740426a47508562ed4dd5", null ],
    [ "setPhaseFractional", "class_oscil.html#afc77bfc5a1ad5926ad8df37725d480d7", null ],
    [ "setPhaseInc", "class_oscil.html#a2ff9bfcc57e07bf0df2ed7db186ecff7", null ],
    [ "setTable", "class_oscil.html#a59e9b132ad0770030d7339c6aa260925", null ]
];