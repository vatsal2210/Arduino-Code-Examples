var class_wave_shaper_3_01char_01_4 =
[
    [ "WaveShaper", "class_wave_shaper_3_01char_01_4.html#a0516cf5c7a3b827b1822480b46af132a", null ],
    [ "next", "class_wave_shaper_3_01char_01_4.html#a8b6327480538c938c846829687ae300f", null ]
];