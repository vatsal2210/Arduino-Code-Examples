var class_a_d_s_r =
[
    [ "ADSR", "class_a_d_s_r.html#ab22c9416a8073d7674ea890a75f97b15", null ],
    [ "next", "class_a_d_s_r.html#aef63b6554045bd61f77d028ad76f1730", null ],
    [ "noteOff", "class_a_d_s_r.html#af6cac55fb97760fffc885507f5d969d2", null ],
    [ "noteOn", "class_a_d_s_r.html#a52091df7bf95f9e34fb51d9707547092", null ],
    [ "setADLevels", "class_a_d_s_r.html#abfb4aaa169920beadb67570e0360f23f", null ],
    [ "setAttackLevel", "class_a_d_s_r.html#aa7fe43c0a91006b5f72013bb5b25fcbb", null ],
    [ "setAttackTime", "class_a_d_s_r.html#ac8e63a0de672b4a91e2123bead6a465b", null ],
    [ "setDecayLevel", "class_a_d_s_r.html#a152312b577df53f02cf92cf4d3b3a4e2", null ],
    [ "setDecayTime", "class_a_d_s_r.html#a1ef68b47f7cdafeab75f0142834e3473", null ],
    [ "setReleaseLevel", "class_a_d_s_r.html#aa577c32f8758e1ecda44b4410c1c103d", null ],
    [ "setReleaseTime", "class_a_d_s_r.html#ab76efe021a258b65da9bc5ec85da2f34", null ],
    [ "setSustainLevel", "class_a_d_s_r.html#a9f81971a62aa3abb66245b7ef25ae3c2", null ],
    [ "setSustainTime", "class_a_d_s_r.html#a5c79838b081aba5a396aa9ea26394051", null ],
    [ "setTimes", "class_a_d_s_r.html#af656b88fdfddd521c3a30fe9b06b524b", null ],
    [ "update", "class_a_d_s_r.html#a5ffeb0baf5e308515ca36cb7af802c31", null ]
];