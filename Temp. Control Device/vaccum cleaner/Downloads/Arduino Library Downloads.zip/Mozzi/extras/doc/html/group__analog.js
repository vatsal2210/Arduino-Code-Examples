var group__analog =
[
    [ "adcDisconnectAllDigitalIns", "group__analog.html#ga5042e7c576dd0307be38eb70efdb69fe", null ],
    [ "adcReconnectAllDigitalIns", "group__analog.html#gabad497d1f8c8026e81849be0b65bf38f", null ],
    [ "disconnectDigitalIn", "group__analog.html#gad4433797b75fedd473250e9aa414dcae", null ],
    [ "getAudioInput", "group__analog.html#ga3f15eb8d6694020d170ebcbedb645de7", null ],
    [ "mozziAnalogRead", "group__analog.html#ga860bfe1e9172d1f5bb8eb08c324cd6c9", null ],
    [ "reconnectDigitalIn", "group__analog.html#gacd83735876cf223916ea4925ec4efd4a", null ],
    [ "setupFastAnalogRead", "group__analog.html#ga8741756d32609ad6dec641943fa99af9", null ]
];