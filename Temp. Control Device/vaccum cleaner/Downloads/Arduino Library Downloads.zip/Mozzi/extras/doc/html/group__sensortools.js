var group__sensortools =
[
    [ "RollingStat", "group__sensortools.html#a98c3f767391db80b8ad59ca53c1e6a94", null ],
    [ "getMean", "group__sensortools.html#aed85e98ab32f0a731dc12f9f1c4da398", null ],
    [ "getStandardDeviation", "group__sensortools.html#ade29f8eea338da4879fa692ea2b28bc3", null ],
    [ "getVariance", "group__sensortools.html#a9d145736669d070194b8149eec084bc0", null ],
    [ "update", "group__sensortools.html#a85750e78ac282caec24408dce6e78201", null ],
    [ "update", "group__sensortools.html#afdc3f385aebe68492514f41129065aa5", null ]
];