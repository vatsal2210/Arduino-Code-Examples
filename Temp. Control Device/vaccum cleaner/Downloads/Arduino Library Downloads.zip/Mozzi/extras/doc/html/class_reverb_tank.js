var class_reverb_tank =
[
    [ "ReverbTank", "class_reverb_tank.html#a2b413e10d5d3688f2066624e5a8ae324", null ],
    [ "next", "class_reverb_tank.html#a4930ae7a871dba610fb141d7ab83d827", null ],
    [ "setEarlyReflections", "class_reverb_tank.html#aeaa523c4fae743ef7ded87d4902af3d7", null ],
    [ "setFeebackLevel", "class_reverb_tank.html#a25ce51abfcaccb316007edc77446520b", null ],
    [ "setLoopDelays", "class_reverb_tank.html#a6c19a84c7bc1f068871551891011a89c", null ]
];