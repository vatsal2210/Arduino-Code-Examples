var char2mozzi_8py =
[
    [ "char2mozzi", "char2mozzi_8py.html#a61b2b967d3c7374f1f6f5296471cc45c", null ]
];