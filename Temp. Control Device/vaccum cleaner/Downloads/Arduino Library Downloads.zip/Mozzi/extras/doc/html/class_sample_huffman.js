var class_sample_huffman =
[
    [ "SampleHuffman", "class_sample_huffman.html#aaf47820439dcf79a5a3fbaf62483e2e5", null ],
    [ "next", "class_sample_huffman.html#aec990357f3b166ef70475c34d374aeda", null ],
    [ "setLoopingOff", "class_sample_huffman.html#a040bfc55c19bbaa6cc42331be3646c8a", null ],
    [ "setLoopingOn", "class_sample_huffman.html#a01f9bfb513da0374fe78c12300b69760", null ],
    [ "start", "class_sample_huffman.html#a15ead859261d3d916d700b75f4626f15", null ]
];