var searchData=
[
  ['reverbtank',['ReverbTank',['../class_reverb_tank.html',1,'']]],
  ['rollingaverage',['RollingAverage',['../group__sensortools.html#class_rolling_average',1,'']]],
  ['rollingaverage_3c_20unsigned_20int_2c_281_3c_3c_28resolution_5fincrease_5fbits_20_2a2_29_29_3e',['RollingAverage&lt; unsigned int,(1&lt;&lt;(RESOLUTION_INCREASE_BITS *2))&gt;',['../group__sensortools.html',1,'']]],
  ['rollingstat',['RollingStat',['../group__sensortools.html#class_rolling_stat',1,'']]]
];
